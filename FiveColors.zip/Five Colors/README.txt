Lauren Ingram
ENTD463 - Winter 2018

Purpose:

This simple project was an assignment requirement for my
Enterprise Development using C# course.




Project Requirements:

Create a project named FiveColors. Its Form contains at least five Button objects, 
each labeled with a color. When the user clicks a Button, 
change the BackColor of the Form appropriately.

The requirements came from the textbook Visual C# 2012: An Introduction of Object-Oriented Programming by Joyce Farrell




How to use:


Launch the program by clicking FiveColors.exe
Click any of the buttons containing a color to change the form's background color
You may continue to change colors, or use the "X' button in to control box to exit the program